<?php
include 'config.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Preparar e executar a consulta SQL para obter os dados do usuário pelo e-mail
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verificar a senha
        if (password_verify($senha, $user['senha'])) {
            // Senha correta, iniciar sessão
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nome'] = $user['nome'];
            $_SESSION['user_email'] = $user['email'];

            // Redirecionar para a página comprando.php
            header("Location: comprando.html");
            exit();
        } else {
            // Senha incorreta
            $mensagem = "Senha incorreta.";
        }
    } else {
        // Usuário não encontrado
        $mensagem = "E-mail não cadastrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/stylelogin.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <title>TÔ | Login</title>
    <style>
        .mensagem-popup {
            margin: 20px 0;
            background-color: white;
            color: black;
            padding: 20px;
            border: 1px solid blueviolet;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
    </style>

<div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
          <div class="vw-plugin-top-wrapper"></div>
        </div>
      </div>
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
      </script> 
</head>
<body>
    <div class="box">
        <div class="container">
            <div class="top-header">
                <span>Tem uma conta?</span>
                <header>TÔ</header>
            </div>

            <?php if(isset($mensagem)): ?>
                <div class="mensagem-popup">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="" method="post">
                <div class="input-field">
                    <input type="text" class="input" id="email-box" name="email" required>
                    <label class="label-email" for="email-box">Seu e-mail</label>
                    <i class="bx bx-user"></i>
                </div>
                <div class="input-field">
                    <input type="password" class="input" id="senha-box" name="senha" required>
                    <label class="label-senha" for="senha-box">Senha</label>
                    <i class="bx bx-lock-alt"></i>
                    <i class="bi bi-eye" id="btn-senha" onclick="mostrarSenha()"></i>
                </div>
                <div class="input-field">
                    <input type="submit" class="submit" value="Entrar">
                </div>
            </form>

            <div class="bottom">
                <div class="right">
                    <label><a href="esqueciasenha.php">Esqueceu a senha?</a></label>
                </div>
            </div>

            <div class="btn-registro">
                <div class="conta">
                    <label><p>Não tem conta?<a href="cadastre-se.php" class="registro"> Registrar-se</a></p></label>
                </div>
            </div>
        </div>
    </div>
    <script src="js/olho.js"></script>
</body>
</html>
