<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style_esqueciasenha.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <title>TÔ | Esqueci a senha</title>
    <style>
        .mensagem-popup {
            margin: 20px 0;
            background-color: white;
            color: black;
            padding: 20px;
            border: 1px solid blueviolet;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
    </style>

<div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
          <div class="vw-plugin-top-wrapper"></div>
        </div>
      </div>
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
      </script> 
</head>
<body>
    <div class="box">
        <div class="container">
            <div class="top-header">
                <span>Esqueceu a senha?</span>
                <header>TÔ</header>
            </div>

            <?php
            // Verifica se o formulário foi submetido
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Conexão com o banco de dados
                include_once 'config.php';

                // Recebe os dados do formulário
                $email = $_POST["email"];
                $nova_senha = $_POST["nova_senha"];

                // Verifica se o e-mail existe no banco de dados
                $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Hash da nova senha
                    $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);

                    // Atualiza a senha no banco de dados
                    $sql = "UPDATE usuarios SET senha='$senha_hash' WHERE email='$email'";

                    if ($conn->query($sql) === TRUE) {
                        $mensagem = "Senha atualizada com sucesso!";
                    } else {
                        $mensagem = "Erro ao atualizar a senha: " . $conn->error;
                    }
                } else {
                    $mensagem = "E-mail não encontrado.";
                }

                // Fecha a conexão com o banco de dados
                $conn->close();
            }
            ?>

            <?php if(isset($mensagem)): ?>
                <div class="mensagem-popup">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="input-field">
                    <input type="text" class="input" id="email-box" name="email" required>
                    <label class="label-email" for="email-box">Seu e-mail</label>
                    <i class="bx bx-user"></i>
                </div>
                <div class="input-field">
                    <input type="password" class="input" id="senha-box" name="nova_senha" required>
                    <label class="label-senha" for="senha-box">Nova senha</label>
                    <i class="bx bx-lock-alt"></i>
                    <i class="bi bi-eye eye-icon" id="btn-senha" onclick="mostrarSenha()"></i>
                </div>
                <div class="input-field">
                    <input type="password" class="input" id="confirma-senha-box" required>
                    <label class="label-senha" for="confirma-senha-box">Confirme sua nova senha</label>
                    <i class="bx bx-lock-alt"></i>
                    <i class="bi bi-eye eye-icon" id="btn-confirma-senha" onclick="mostrarSenhaConfirma()"></i>
                </div>            
                <div class="input-field">
                    <input type="submit" class="submit" value="Registrar nova senha">
                </div>
            </form>
            <div class="btn-registro">
                <div class="conta">
                    <label><p>Não tem conta?<a href="cadastre-se.php" class="registro"> Registrar-se</a></p></label>
                </div>
            </div>
        </div>
    </div>
    <script src="js/olho.js"></script>
</body>
</html>