document.addEventListener("DOMContentLoaded", function() {
    const closeButton = document.querySelector(".fechar-lupa");
    const searchInput = document.querySelector("#searchInput");
    const feedItems = document.querySelectorAll(".card");

    closeButton.addEventListener("click", function() {
        searchInput.value = "";
        filterFeed("");
    });

    searchInput.addEventListener("input", function() {
        const searchTerm = searchInput.value.trim().toLowerCase();
        filterFeed(searchTerm);
    });

    function filterFeed(searchTerm) {
        feedItems.forEach(function(item) {
            const name = item.querySelector(".name").textContent.toLowerCase();
            const description = item.querySelector(".description").textContent.toLowerCase();
            if (name.includes(searchTerm) || description.includes(searchTerm)) {
                item.style.visibility = "visible";
                item.style.display = "block";
            } else {
                item.style.visibility = "hidden";
                item.style.display = "none";
            }
        });
    }
});