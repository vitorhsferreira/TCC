document.addEventListener("DOMContentLoaded", function() {
    const closeButton = document.querySelector(".fechar-lupa");
    const searchInput = document.querySelector("#searchInput");
    const feedItems = document.querySelectorAll(".feed-item");

    closeButton.addEventListener("click", function() {
        searchInput.value = "";
        filterFeed("");
    });

    searchInput.addEventListener("input", function() {
        const searchTerm = searchInput.value.toLowerCase();
        filterFeed(searchTerm);
    });

    function filterFeed(searchTerm) {
        feedItems.forEach(function(item) {
            const text = item.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                item.style.visibility = "visible";
                item.style.display = "block";
            } else {
                item.style.visibility = "hidden";
                item.style.display = "none";
            }
        });
    }
});