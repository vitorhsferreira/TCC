document.addEventListener('DOMContentLoaded', function() {
    const userMenu = document.querySelector('.user-menu');
    const submenu = document.querySelector('.submenu');
    const userIcon = userMenu.querySelector('a');

    userIcon.addEventListener('click', function(event) {
        event.preventDefault(); // Previne apenas o clique no ícone
        submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
    });

    // Opcional: Fechar o submenu se clicar fora dele
    document.addEventListener('click', function(event) {
        if (!userMenu.contains(event.target)) {
            submenu.style.display = 'none';
        }
    });
});
