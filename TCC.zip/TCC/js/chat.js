document.addEventListener("DOMContentLoaded", () => {
    const chatWindow = document.getElementById("chat-window");
    const chatInput = document.getElementById("chat-input");
    const sendButton = document.getElementById("send-button");

    sendButton.addEventListener("click", sendMessage);
    chatInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

    function sendMessage() {
        const messageText = chatInput.value.trim();
        if (messageText !== "") {
            appendMessage(messageText, "sent");
            chatInput.value = "";
            simulateReceivedMessage(messageText);
        }
    }

    function appendMessage(text, type) {
        const messageElement = document.createElement("div");
        messageElement.className = `message ${type}`;
        messageElement.textContent = text;
        chatWindow.appendChild(messageElement);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    function simulateReceivedMessage(sentText) {
        setTimeout(() => {
            const receivedText = `Resposta: ${sentText}`;
            appendMessage(receivedText, "received");
        }, 1000);
    }
});