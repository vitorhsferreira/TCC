// Função para verificar se o usuário está logado
function isUserLoggedIn() {
    // Exemplo usando localStorage
    return localStorage.getItem('loggedIn') === 'true';
}

// Função para redirecionar com base no estado de login para "COMPRANDO"
function handleComprarLinkClick(event) {
    event.preventDefault(); // Evita o comportamento padrão do link
    if (isUserLoggedIn()) {
        window.location.href = 'comprando.html';
    } else {
        window.location.href = 'login.php';
    }
}

// Função para redirecionar com base no estado de login para "VENDENDO"
function handleVenderLinkClick(event) {
    event.preventDefault(); // Evita o comportamento padrão do link
    if (isUserLoggedIn()) {
        window.location.href = 'vendendo.html';
    } else {
        window.location.href = 'login.php';
    }
}

// Função para redirecionar com base no estado de login para "POSTAR"
function handlePostarLinkClick(event) {
    event.preventDefault(); // Evita o comportamento padrão do link
    if (isUserLoggedIn()) {
        window.location.href = 'postar.html';
    } else {
        window.location.href = 'login.php';
    }
}

// Adiciona eventos de clique aos links "COMPRANDO", "VENDENDO" e "POSTAR"
document.getElementById('comprar-link').addEventListener('click', handleComprarLinkClick);
document.getElementById('vender-link').addEventListener('click', handleVenderLinkClick);
document.getElementById('postar-link').addEventListener('click', handlePostarLinkClick);
document.getElementById('ver-mais').addEventListener('click', handlePostarLinkClick);