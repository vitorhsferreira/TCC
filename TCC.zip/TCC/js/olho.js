function mostrarSenha() {
    var senhaBox = document.getElementById('senha-box');
    var btnSenha = document.getElementById('btn-senha');
    if (senhaBox.type === 'password') {
        senhaBox.type = 'text';
        btnSenha.classList.remove('bi-eye');
        btnSenha.classList.add('bi-eye-slash');
    } else {
        senhaBox.type = 'password';
        btnSenha.classList.remove('bi-eye-slash');
        btnSenha.classList.add('bi-eye');
    }
}

function mostrarSenhaConfirma() {
    var confirmaSenhaBox = document.getElementById('confirma-senha-box');
    var btnConfirmaSenha = document.getElementById('btn-confirma-senha');
    if (confirmaSenhaBox.type === 'password') {
        confirmaSenhaBox.type = 'text';
        btnConfirmaSenha.classList.remove('bi-eye');
        btnConfirmaSenha.classList.add('bi-eye-slash');
    } else {
        confirmaSenhaBox.type = 'password';
        btnConfirmaSenha.classList.remove('bi-eye-slash');
        btnConfirmaSenha.classList.add('bi-eye');
    }
}